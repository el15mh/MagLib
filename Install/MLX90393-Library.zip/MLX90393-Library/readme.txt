Library for the MLX90393 Device on the Arduino Platform.
Version 1.0

Tested using Arduino Due.

Note use pins 20 (SDA) and 21 (SCL) for I2C bus.
Ensure to install Arduino ARM (32-bit) Boards in Arduino IDE Boards Manager and select Arduino Due (Programming Port), NOT Native Port.

Author - Max Houghton
Date 05/06/2018